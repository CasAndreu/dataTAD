# dataTAD
This python module provides a set of example datasets used in the notes, modules, and exercises of my -Text as Data for Social Science Research- teaching material. You can access the materials in the following website: http://andreucasas.com/text_as_data/
